<!-- Please help me process issues faster by providing the following information -->
### I'm submitting a...
- [x] Bug report
- [ ] Feature request

### Reproduction steps
<!-- Bonus points if you set up a [JSFiddle](https://jsfiddle.net/) that replicates the bug and link it in the issue. -->
1. ...
2. ...

### Version information
Browser type and version:
EasyMDE version:
