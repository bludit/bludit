<?php defined('BLUDIT') or die('Bludit CMS.'); ?>
{
    "news": {
        "name": "News",
        "list": []
    },
    "sleeping-city": {
        "name": "Sleeping city",
        "list": []
    }
}