<?php defined('BLUDIT') or die('Bludit CMS.'); ?>
{
    "label": "Menu",
    "homeLink": false,
    "position": 1
}