<?php defined('BLUDIT') or die('Bludit CMS.'); ?>
{
    "label": "Categories",
    "hideCero": true,
    "position": 1
}