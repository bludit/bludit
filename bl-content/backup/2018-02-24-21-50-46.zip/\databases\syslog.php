<?php defined('BLUDIT') or die('Bludit CMS.'); ?>
[
    {
        "date": "2018-02-24 21:50:46",
        "dictionaryKey": "plugin-configured",
        "notes": "Backup",
        "idExecution": "5a91c2161a02c",
        "method": "POST",
        "username": "admin"
    },
    {
        "date": "2018-02-24 21:50:39",
        "dictionaryKey": "plugin-activated",
        "notes": "Backup",
        "idExecution": "5a91c20ef3b17",
        "method": "GET",
        "username": "admin"
    },
    {
        "date": "2018-02-24 21:50:34",
        "dictionaryKey": "plugin-deactivated",
        "notes": "Version",
        "idExecution": "5a91c20a837bb",
        "method": "GET",
        "username": "admin"
    },
    {
        "date": "2018-02-24 21:50:28",
        "dictionaryKey": "plugin-activated",
        "notes": "Version",
        "idExecution": "5a91c2044fc5f",
        "method": "GET",
        "username": "admin"
    },
    {
        "date": "2018-02-24 21:49:39",
        "dictionaryKey": "plugin-activated",
        "notes": "Open Graph",
        "idExecution": "5a91c1d34e23d",
        "method": "GET",
        "username": "admin"
    },
    {
        "date": "2018-02-24 21:48:36",
        "dictionaryKey": "plugin-configured",
        "notes": "Latest content",
        "idExecution": "5a91c194e288b",
        "method": "POST",
        "username": "admin"
    },
    {
        "date": "2018-02-24 21:48:17",
        "dictionaryKey": "plugin-activated",
        "notes": "Latest content",
        "idExecution": "5a91c181a3f60",
        "method": "GET",
        "username": "admin"
    },
    {
        "date": "2018-02-24 21:48:04",
        "dictionaryKey": "plugin-deactivated",
        "notes": "Menu",
        "idExecution": "5a91c17433bf9",
        "method": "GET",
        "username": "admin"
    },
    {
        "date": "2018-02-24 21:47:51",
        "dictionaryKey": "plugin-configured",
        "notes": "Categories",
        "idExecution": "5a91c167a463e",
        "method": "POST",
        "username": "admin"
    },
    {
        "date": "2018-02-24 21:47:40",
        "dictionaryKey": "plugin-configured",
        "notes": "Categories",
        "idExecution": "5a91c15c70ecc",
        "method": "POST",
        "username": "admin"
    }
]