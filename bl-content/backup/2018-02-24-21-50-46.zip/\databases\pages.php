<?php defined('BLUDIT') or die('Bludit CMS.'); ?>
{
    "about-us": {
        "description": "",
        "username": "admin",
        "tags": [],
        "status": "static",
        "type": "page",
        "date": "2018-02-24 16:32:52",
        "dateModified": "2018-02-24 21:35:40",
        "position": 3,
        "coverImage": "portal.jpg",
        "category": "",
        "md5file": "15ad608af1afcc0cd474dd75b79a1a16",
        "uuid": "f6eb7016beef5df5f8f5865a7de880d6",
        "allowComments": true,
        "template": ""
    },
    "support-us": {
        "description": "",
        "username": "admin",
        "tags": [],
        "status": "static",
        "type": "page",
        "date": "2018-02-24 20:03:10",
        "dateModified": "2018-02-24 21:37:55",
        "position": 5,
        "coverImage": "gears.jpg",
        "category": "",
        "md5file": "a73fdf8091a6bd254ec7843a7124ffe1",
        "uuid": "3259b25dc26651b66332c5f88283a422",
        "allowComments": true,
        "template": ""
    },
    "klaida": {
        "description": "",
        "username": "admin",
        "tags": [],
        "status": "published",
        "type": "page",
        "date": "2018-02-24 20:51:17",
        "dateModified": "2018-02-24 21:13:39",
        "position": 6,
        "coverImage": "error.jpg",
        "category": "",
        "md5file": "548a94d94b99f3699839ea291d9c0856",
        "uuid": "9719276def511a2ef151090d0f95ef40",
        "allowComments": true,
        "template": ""
    }
}