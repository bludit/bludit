<?php defined('BLUDIT') or die('Bludit CMS.'); ?>
{
    "minutesBlocked": 5,
    "numberFailuresAllowed": 10,
    "blackList": {
        "127.0.0.1": {
            "lastFailure": 1519500162,
            "numberFailures": 10
        }
    }
}