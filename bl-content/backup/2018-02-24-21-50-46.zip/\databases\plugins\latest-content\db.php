<?php defined('BLUDIT') or die('Bludit CMS.'); ?>
{
    "label": "Latest content",
    "homeLink": true,
    "amountOfItems": 5,
    "position": 1
}