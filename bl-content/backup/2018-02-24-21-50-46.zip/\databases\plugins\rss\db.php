<?php defined('BLUDIT') or die('Bludit CMS.'); ?>
{
    "amountOfItems": 5,
    "position": 0
}