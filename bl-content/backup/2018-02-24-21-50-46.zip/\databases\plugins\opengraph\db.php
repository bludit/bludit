<?php defined('BLUDIT') or die('Bludit CMS.'); ?>
{
    "defaultImage": "",
    "position": 1
}