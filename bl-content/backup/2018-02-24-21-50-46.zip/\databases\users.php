<?php defined('BLUDIT') or die('Bludit CMS.'); ?>
{
    "admin": {
        "firstName": "Andrius",
        "lastName": "Pratusis",
        "role": "admin",
        "password": "",
        "salt": "5a91bce06a6d3",
        "email": "andrius.pratusis1993@gmail.com",
        "registered": "2018-02-23 20:23:13",
        "tokenRemember": "",
        "tokenAuth": "51f25620d7c979f6405cad3f0e803d3f",
        "tokenAuthTTL": "2009-03-15 14:00",
        "twitter": "",
        "facebook": "https:\/\/www.facebook.com\/andriuspratusis",
        "googlePlus": "",
        "instagram": "",
        "username": "admin",
        "codepen": ""
    }
}